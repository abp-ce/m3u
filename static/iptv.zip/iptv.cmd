@echo off
set str=%1
@start "" "D:\Program Files\VideoLAN\VLC\vlc.exe" %str:~6%
@rem start "" "D:\Program Files\DAUM\PotPlayer\PotPlayerMini64.exe" %str:~6%
